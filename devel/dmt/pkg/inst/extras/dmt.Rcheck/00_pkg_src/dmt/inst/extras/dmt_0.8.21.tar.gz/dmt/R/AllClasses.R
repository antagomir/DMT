setClass("DependencyModel", 
         representation(W = "list", 
                        phi = "list", 
                        score = "numeric",
                        method = "character", 
                        params = "list",
                        data = "list",
                        z = "matrix"))


