# For info on Travis R scripts, see
# http://jtleek.com/protocols/travis_bioc_devel/

# Roxygen tips:
# http://r-pkgs.had.co.nz/man.html

/usr/bin/R CMD BATCH document.R
/usr/bin/R CMD build ../../ # --no-build-vignettes
/usr/bin/R CMD check --as-cran dmt_0.8.21.tar.gz # --no-build-vignettes
/usr/bin/R CMD INSTALL dmt_0.8.21.tar.gz
#/usr/bin/R CMD BATCH document.R

